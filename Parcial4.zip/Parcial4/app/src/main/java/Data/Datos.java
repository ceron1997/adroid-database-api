package Data;

public class Datos {
    public static String Usuario;
    public static String DP;
    public static  String MN;
}
