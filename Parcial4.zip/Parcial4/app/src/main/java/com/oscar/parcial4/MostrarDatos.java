package com.oscar.parcial4;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.sql.ResultSet;

import Data.Datos;

public class MostrarDatos extends AppCompatActivity {
TextView tvDatos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_datos);

        tvDatos=findViewById(R.id.tvDatos);
        String e="     ";
        tvDatos.setText("USUARIO: "+e+ Datos.Usuario+"\n\n"+
                             "DEPARTAMENTO:"+e+Datos.DP+"\n\n"+
                             "MUNICIPIO: "+e+Datos.MN);
    }
    public void regresar(View v){
        Intent i=new Intent(this,listarMN.class);
        setResult(Activity.RESULT_OK,i);
        finish();
    }
    public void muni(View v){
        finish();
    }


}