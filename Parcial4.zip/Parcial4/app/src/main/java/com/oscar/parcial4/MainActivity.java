package com.oscar.parcial4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import DBconf.DBEstructura;
import DBconf.DBHelper;
import Data.Datos;

public class MainActivity extends AppCompatActivity {
    EditText edtCorreo,edtClave;
    DBHelper helper= new DBHelper(this, DBHelper.DBName,null,DBHelper.Version);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        edtCorreo.setText("admin@gmail.com");
        edtClave.setText("123");
    }

    private void init(){
        edtCorreo=findViewById(R.id.edtCorreo);
        edtClave=findViewById(R.id.edtClave);
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor cursor= db.query(DBEstructura.TablaUsuario,null,null,null,null,null,null);
            if(cursor.getCount()<=0){
                if(addUser("admin@gmail.com","123")){
                  edtCorreo.setText("oscar@gmail.com");
                  edtClave.setText("123");
                  searchDP();
                  searchMN();
                }
            }
            cursor.close();



    }

    private void searchDP(){
        try {
            SQLiteDatabase db =helper.getReadableDatabase();
            Cursor cursor = db.query(DBEstructura.TablaDepartamentos, null, null, null, null, null, null);
            if (cursor.getCount() <= 0) {
            int[] ID = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
            String[] DP = {"Ahuachapán","Santa Ana","Sonsonate","Usulután","San Miguel","Morazán","La Unión",
                    "La Libertad","Chalatenango","Cuscatlán","San Salvador (la capital)","La Paz","Cabañas",
                    "San Vicente"};

            if (addDP(ID, DP)) {
                Toast.makeText(this, "Deparatamentos ingresados con exito", Toast.LENGTH_LONG).show();
            }
            }
            cursor.close();
        }catch (SQLException e){
            Log.i("mjss",e.toString());

        }

    }

    private void searchMN(){
        try {
            SQLiteDatabase db =helper.getReadableDatabase();
            Cursor cursor = db.query(DBEstructura.TablaMunicipios, null, null, null, null, null, null);
            if (cursor.getCount() <= 0) {
                int i = 11;
                String[] DP = {"1. Ahuachapán","2. Jujutla","3. Atiquizaya","4. Concepción de Ataco"  ,"5. El Refugio","6. Guaymango","7. Apaneca","8. San Francisco Menéndez","9. San Lorenzo","10. San Pedro Puxtla","11. Tacuba",
                        "Candelaria de la Frontera 91.13 km² 33,550 hab.","Chalchuapa 165.76 km² 86,200 hab.","Coatepeque 126.85 km² 48,544 hab.","El Congo 91.43 km² 22,274 hab.","El Porvenir 52.52 km² 7,819 hab.","Masahuat 71.23 km² 5,125 hab.","Metapán 668.36 km² 59,499 hab.","San Antonio Pajonal 51.92 km² 4,574 hab.","San Sebastián Salitrillo 42.32 km² 16,688 hab.","Santa Ana 400.05 km² 261,568 hab.","Santa Rosa Guachipilín 38.41 km² 7,909 hab.",
                        "1. Acajutla","2. Armenia","3. Caluco","4. Cuisnahuat","5. Izalco","6. Juayúa","7. Nahuizalco","8. Nahulingo","9. Salcoatitán","10. San Antonio del Monte","11. San Julián",
                        "1. Alegría", "2. Berlín", "3. California", "4. Concepción Batres", "5. El Triunfo", "6. Ereguayquín", "7. Estanzuelas", "8. Jiquilisco", "9. Jucuapa", "10. Jucuarán", "11. Mercedes Umaña",
                        "1. Carolina","2. Chapeltique","3. Chinameca","4. Chirilagua","5. Ciudad Barrios","6. Comacarán","7. El Tránsito","8. Lolotique","9. Moncagua","10. Nueva Guadalupe","11. Nuevo Edén de San Juan",
                        "Arambala 114.21 km² 2,129 hab.", "Cacaopera 135.73 km² 10,558 hab.", "Chilanga 34.33 km² 9,105 hab.", "Corinto 94.99 km² 17,557 hab.", "Delicias de Concepción 20.22 km² 4,980 hab.", "El Divisadero 61.36 km² 8,058 hab.", "El Rosario 19.12 km² 1,296 hab.", "Gualococti 18.62 km² 3,336 hab.", "Guatajiagua 70.77 km² 10,907 hab.", "Joateca 66.27 km² 3,886 hab.", "Jocoaitique 51.85 km² 2,325 hab.",
                        "* La Unión (ciudad)","* San Alejo (ciudad),","* Yucuaiquín (ciudad),","* Conchagua (ciudad),","* Intipucá (villa),","* San José (villa),","* El Carmen (villa),","* Yayantique (pueblo),","* Bolívar (pueblo),","* Meanguera del Golfo (pueblo)","* Santa Rosa de Lima (ciudad),",
                        "1. Antiguo Cuscatlán","2. Chiltiupán","3. Ciudad Arce","4. Colón","5. Comasagua","6. Huizúcar","7. Jayaque","8. Jicalapa","9. La Libertad","10. Santa Tecla","11. Nuevo Cuscatlán",
                        "1. Agua Caliente", "2. Arcatao", "3. Azacualpa", "4. Chalatenango (ciudad)", "5. Citalá", "6. Comalapa", "7. Concepción Quezaltepeque", "8. Dulce Nombre de María", "9. El Carrizal", "10. El Paraíso", "11. La Laguna",
                        "1. Candelaria","2. Cojutepeque","3. El Carmen","4. El Rosario","5. Monte San Juan","6. Oratorio de Concepción","7. San Bartolomé Perulapía","8. San Cristóbal","9. San José Guayabal","10. San Pedro Perulapán","11. San Rafael Cedros",
                        "* Aguilares","* Apopa","* Ayutuxtepeque","* Cuscatancingo","* Delgado","* El Paisnal","* Guazapa","* Ilopango","* Mejicanos","* Nejapa","* Panchimalco",
                        "* Cuyul***án","* El Rosario","* Jerusalén","* Mercedes La Ceiba","* Olocuilta","* Paraíso de Osorio","* San Antonio Masahuat","* San Emigdio","* San Francisco Chinameca","* San Juan Nonualco","* San Juan Talpa",
                        "Cinquera 34.51 km² 757 hab.","Dolores 149.05 km² 6,143 hab.","Guacotecti 21.01 km² 4,424 hab.","Ilobasco 249.69 km² 64, 249 hab.","Jutiapa 67.12 km² 7,866 hab.","San Isidro 78.33 km² 10,422 hab.","Sensuntepeque 306.33 km² 41,215 hab.","Tejutepeque 50.52 km² 5,480 hab.","Victoria 146.95 km² 14,796 hab.","Guacotecti 21.01 km² 4,424 hab.","Sensuntepeque 306.33 km² 41,215 hab.",
                        "Apastepeque 120.56 km² 20,285 hab.","Guadalupe 21.51 km² 6,369 hab.","San Cayetano Istepeque 17.01 km² 6,473 hab.","San Esteban Catarina 78.14 km² 4,147 hab.","San Ildefonso 136.37 km² 10,015 hab.","San Lorenzo 18.71 km² 7,027 hab.","San Sebastián 61.83 km² 15,193 hab.","San Vicente 267.25 km² 52,404 hab.","Santa Clara 124.46 km² 5,145 hab.","Santo Domingo 16.41 km² 7,962 hab.","Tecoluca 284.65 km² 20,065 hab."


                };
                if (addMN(i, DP)) {
                    Toast.makeText(this, "Municipios Registrado con exito ", Toast.LENGTH_LONG).show();
                }
            }
            cursor.close();
        }catch (SQLException e){
            Log.i("mjss",e.toString());

        }

    }
    private boolean addMN(int  cant,String[]MN){
        try {
            int contador=0;
          int j=1;
            SQLiteDatabase db = helper.getWritableDatabase();
            ContentValues values = new ContentValues();
            for (int i = 0; i < MN.length; i++) {

                values.put(DBEstructura.idmunicipio, i);
                values.put(DBEstructura.iddepartamento,contador);
                values.put(DBEstructura.municipio,MN[i]);

                    db.insert(DBEstructura.TablaMunicipios, null, values);
                    values.clear();

                    if(i==(MN.length-1)){
                        return true;
                    }
                    if (j==cant) {
                        j=0;
                        contador++;
                    }
                        j++;


            }
        }catch (Exception e){
            Log.i("msj",e.toString());
        }
        return false;
    }

    private boolean addUser(String correo,String clave){
        SQLiteDatabase db=helper.getWritableDatabase();
        ContentValues values =new ContentValues();
        values.put(DBEstructura.correo,correo);
        values.put(DBEstructura.clave,clave);
        long i = db.insert(DBEstructura.TablaUsuario,null,values);
        if (i!=-1){
            return true;
        }
        return false;
    }

    private boolean addDP(int [] ID,String []DP){
        try {


            SQLiteDatabase db = helper.getWritableDatabase();
            ContentValues values = new ContentValues();
            for (int i = 0; i < ID.length; i++) {
                values.put(DBEstructura.iddepartamento, ID[i]);
                values.put(DBEstructura.departamento, DP[i]);
                db.insert(DBEstructura.TablaDepartamentos, null, values);
                values.clear();
                if (i == 13) {
                    return true;
                }
            }
        }catch (Exception e){
            Log.i("msj",e.toString());
        }
        return false;

    }

    private boolean searchUser(String correo,String clave){
        String dato[]={correo};
        String where=DBEstructura.correo+" LIKE?";
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor cursor= db.query(DBEstructura.TablaUsuario,null,where,dato,null,null,null);
        if(cursor.getCount()>0){
            if(cursor.moveToNext()){
                if(cursor.getString(1).equals(clave)){
                    Datos.Usuario=correo;
                    return true;
                }
            }
        }
        cursor.close();
        return false;
    }

    private boolean validarcampos(String correo ,String clave){
        if(correo.isEmpty()){
            edtCorreo.setError("Dato requerido");
            return false;
        }else if(clave.isEmpty()){
            edtClave.setError("Dato requerido");
            return false;
        }
        return true;

    }
    public void iniciar(View v){
        String correo=edtCorreo.getText().toString().trim();
        String clave=edtClave.getText().toString().trim();
        if(validarcampos(correo,clave)){
            if (searchUser(correo,clave)){
                Intent i= new Intent(this,ListarDP.class);
                startActivity(i);
                finish();
            }
        }
    }




}