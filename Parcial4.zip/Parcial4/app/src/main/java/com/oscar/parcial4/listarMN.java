package com.oscar.parcial4;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import DBconf.DBEstructura;
import DBconf.DBHelper;
import Data.Datos;

public class listarMN extends AppCompatActivity {
ListView lvlistar;
ArrayList <String> MN=new ArrayList<String>();
DBHelper helper=new DBHelper(this,DBHelper.DBName,null,DBHelper.Version);
static final int listarmn=1;
boolean exist=false;
TextView tvTitulo2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_mn);
        lvlistar=findViewById(R.id.lvlistar);
        tvTitulo2=findViewById(R.id.tvTitulo2);
        tvTitulo2.setText("Municipios de "+Datos.DP);
        MN.add("sin datos");
        String i=""+getIntent().getIntExtra("dp",0);
        String []dato={i};
        String where=DBEstructura.iddepartamento+" LIKE?";
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor cursor=db.query(DBEstructura.TablaMunicipios,null,where,dato,null,null,null);
        if(cursor.getCount()>0){
            MN.clear();
            while(cursor.moveToNext()){
                MN.add(cursor.getString(2));
            }
        }

        ArrayAdapter <String> adapter=new ArrayAdapter<>(this, R.layout.filas,MN);
        lvlistar.setAdapter(adapter);


        lvlistar.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Datos.MN=MN.get(i);
                activity();

            }
        });




    }
    private void activity(){
        Intent i =new Intent(this,MostrarDatos.class);
        startActivityForResult(i,listarmn);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==listarmn && resultCode==RESULT_OK){
            finish();
        }
    }
}