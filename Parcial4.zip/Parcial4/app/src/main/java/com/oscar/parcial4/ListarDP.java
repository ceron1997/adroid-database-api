package com.oscar.parcial4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import DBconf.DBEstructura;
import DBconf.DBHelper;
import Data.Datos;

public class ListarDP extends AppCompatActivity {
    ListView lvlista;
    ArrayList<String> DP=new ArrayList<String>();
    DBHelper helper = new DBHelper(this, DBHelper.DBName, null, DBHelper.Version);
    boolean exits = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar);
        DP.add("sin datos");
        lvlista=findViewById(R.id.lvlista);

        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor cursor = db.query(DBEstructura.TablaDepartamentos, null, null, null, null, null, null);
        if (cursor.getCount() > 0) {
            DP.clear();
            while (cursor.moveToNext()) {
                DP.add(cursor.getString(1));
            }
            exits = true;

        }else {
            DP.add("NO existen Datos");
        }

        cursor.close();
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, R.layout.filas, DP);
       lvlista.setAdapter(ad);

        lvlista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    if(exits){

                        Datos.DP=DP.get(i);
                        activity(i);
                    }


                }catch (Exception e){
                    Toast.makeText(getApplication(),e.toString(),Toast.LENGTH_LONG).show();
                }
            }
        });




    }
    private void activity(int i){
        Intent intent=new Intent(this,listarMN.class);
        intent.putExtra("dp",i);
        startActivity(intent);
    }


}