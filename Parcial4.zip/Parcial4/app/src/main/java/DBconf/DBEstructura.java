package DBconf;

public class DBEstructura {
    public static final String TablaUsuario="Usuarios";
    public static final String correo="correo";
    public static final String clave="clave";

    public static final String TablaDepartamentos="Departamentos";
    public static final String iddepartamento="ID_Departamento";
    public static final String departamento="departamento";

    public static final String TablaMunicipios="Municipios";
    public static final String idmunicipio="ID_Municipio";
    public static final String municipio="municipio";

    public static final String q1="create table "+TablaUsuario+" (\n"+
            correo+" varchar(50) primary key,\n "+
            clave+" varchar(50) );\n"
            ;

    public static final String q2="create table "+TablaDepartamentos+" (\n"+
            iddepartamento+" integer primary key ,\n"+
            departamento+" varchar (50) ); \n"
            ;
    public static final String q3="create table "+TablaMunicipios+" (\n"+
            idmunicipio+" integer primary key,\n"+
            iddepartamento+" integer ,\n"+
            municipio+" varchar(50),\n" +
            "FOREIGN key ("+iddepartamento+") references "+TablaDepartamentos+"("+iddepartamento+")  );";

    public static final String CreateSql=q1+""+q2+""+q3;

    public static final String DeleteSql="drop table IF EXISTS"+TablaUsuario+" ;\n"+
                                          "drop table IF EXISTS"+TablaDepartamentos+" ;\n"+
                                           "drop table IF EXISTS"+TablaMunicipios+" ;";

}
